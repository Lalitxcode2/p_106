function start_classify(){
    navigator.mediaDevices.getUserMedia({audio: true});
    classifier = ml5.soundClassify('https://teachablemachine.withgoogle.com/models/-40yZbCQX/model.json',modelReady);
}

function modelReady(){
    console.log("Model Loaded");
}